function isChecked(chk, sub1){
	console.log(sub1);
	var myLayer = document.getElementById(sub1);
	if(chk.cheked == true){
		myLayer.disabled = false;
	}else{
       myLayer.disabled = true;
	};
}