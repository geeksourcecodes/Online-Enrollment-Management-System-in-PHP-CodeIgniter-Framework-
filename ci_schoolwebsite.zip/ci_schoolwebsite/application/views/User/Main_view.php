<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>

    <meta http-equiv="content-type" content="text/html;charset=UTF-8" />
    <meta charset="utf-8">
    <title>School Website</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no"> 
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no"> 

   <link rel="icon" href="<?php echo base_url();?>assets/img/eqwe.jpg" type="image/x-icon" />
	 <link rel="stylesheet" href="assets/css/bootstrap.min.css">
   <script src="assets/js/jquery.min.js"></script>
   <script src="assets/jquery_ko.js"></script>

  <script src="assets/js/jquery-slim.min.js"></script>
  <script src="assets/js/popper.min.js"></script>
  <script src="assets/js/bootstrap.min.js"></script>

  <script src="assets/jquery.js"></script>
  <script src="assets/jquery.min.js"></script>


  <script type="text/javascript">
    function isChecked(checked, sub1){
    document.getElementById(sub1).disabled = !checkbox.checked;
    }
</script>

	<style type="text/css">
  body{
   /* background-image: url('assets/img/dust_scratches.png');*/
   background-color: #F7F7F7;
    font-family: "Times New Roman", Times, serif;
  }

		#loader{
		    position: fixed;
		    left: 0px;
		    top: 0px;
		    width: 100%;
		    height: 100%;
		    z-index: 9999;
		    background: url('assets/img/Loading_icon.gif') 50% 50% no-repeat rgb(249,249,249);
		    opacity: 1;
		}
    .display-6{
      color: #006bb3;
    }
      #content{
        -webkit-touch-callout: none;
        -webkit-user-select: none;
        -khtml-user-select: none;
        -moz-user-select: none;
        -ms-user-select: none;
        user-select: none;
      }
    body{
      background-image: url('assets/img/honey_im_subtle.png');

    }
	</style>
</head>
<body >
  <!--<div id="loader"></div>-->

	<nav class="navbar navbar-expand-lg navbar-light bg-light sticky-top" style="border-bottom: 1px solid #e0e2e4;width: 100%!important" >
  <a class="navbar-brand" href="#"></a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo02" aria-controls="navbarTogglerDemo02" aria-expanded="false" aria-label="Toggle navigation">
  <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarTogglerDemo02">
    <ul class="navbar-nav mr-auto mt-2 mt-lg-0">
    <li class="nav-item">
    <a class="nav-link" href="#"><img src="assets/img/mainheader.jpg" width="60%" class="img-responsive"></a>
  </li>
    </ul>
   <!-- <form class="form-inline my-2 my-lg-0">-->
      <button class="btn btn-outline-info my-2 my-sm-0" type="submit" style="border:none"><b>LOGIN</b> </button>&nbsp;&nbsp;<button class="btn btn-outline-info my-2 my-sm-0" type="submit" style="border:none"><b>APPLY ONLINE</b></button>  
    <!--</form>-->
  </div>
</nav>
<br>
<br>
<br>
<div class="container">
<div class="jumbotron" style="background-color: white;opacity: 1.0;border-top: 4px solid #00cc7a;border-radius: 4px">
  <div class="row">
  <div class="col-md-6">
       <img src="assets/img/dasd.jpg"  class="img-responsive">

    </div>
    <div class="col-md-6">
 <h3 class="display-6">I want to be a ICCT Student</h3>
 <div class="custom-controls-stacked d-block my-3">
   <label class="custom-control custom-checkbox mb-4 mr-sm-4 mb-sm-2">
    <input type="checkbox" class="custom-control-input"  id="checkbox" onchange="isChecked(this, 'sub1')">
      <span class="custom-control-indicator"></span>
     <p style="text-indent: 0px;word-wrap:break-word;" class="text-muted" id="content">Please Click Checkbox to Proceed Next Step<br><br> <!-- <font color="#006bb3">Terms and Condition.</font> All informations needed in next<br> pages will be save in our list and you agree that you data will be share to us.</p>
    </div> -->
    

 <a href="<?php echo base_url();?>Main/view_tabs"><input type="submit" class="btn btn-lg btn-primary btnNext" name="submit" value="Sign Up" id="sub1" disabled="disabled" style="color:white; width: 250px;"></a>
</div>
  </p>
</div>
</div>
</div>
</body>
  </div>
  </div>
</div>
</div>
<script src="jquery.min.js"></script>
<script type="text/javascript">
	$(window).on('load', function(){
		//you remove this timeout
		setTimeout(function(){
	        $('#loader').fadeOut('slow');  
	    }, 1000);
	    //remove the timeout
	    //$('#loader').fadeOut('slow'); 
	});
</script>
</body>
<center>
<br><br><br><br><br><br>
<div class="container">
<div class="footer">
 <p style="text-indent: 0px;word-wrap:break-word;" class="text-muted" id="content"> &copy; <?php echo date('Y');?><!--<?php// echo date("Y");?>--> <font color="#006bb3">ICCT Colleges</font> All Rights Reserved</p>
</div>
</div>
</center>
</html>