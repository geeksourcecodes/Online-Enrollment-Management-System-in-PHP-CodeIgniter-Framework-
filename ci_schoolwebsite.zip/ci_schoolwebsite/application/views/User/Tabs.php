<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>

    <meta http-equiv="content-type" content="text/html;charset=UTF-8" />
    <meta charset="utf-8">
    <title>School Website</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link rel="icon" href="<?php echo base_url();?>assets/img/eqwe.jpg" type="image/x-icon" />
   <link rel="stylesheet" href="<?php echo base_url();?>assets2/assets/signup-form.css" type="text/css" />
   <script src="<?php echo base_url();?>assets2/jquery.js"></script>  

   <link rel="stylesheet" href="<?php echo base_url();?>assets/css/bootstrap.min.css">
   <script src="<?php echo base_url();?>assets/js/jquery.min.js"></script>
   <script src="<?php echo base_url();?>assets/jquery_ko.js"></script>

  <script src="<?php echo base_url();?>assets/js/jquery-slim.min.js"></script>
  <script src="<?php echo base_url();?>assets/js/popper.min.js"></script>
  <script src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>

   <script src="<?php echo base_url();?>assets2/assets/jquery.validate.min.js"></script>

    <!-- <script type="text/javascript">

      function CheckAndSubmit(id){

    var contactno = document.getElementById ("contactno");
    if(contactno.value.length < 10) {
      alert("The Contact Number must be at least 10/11 Digits!");
      return false;
    }
    return true;
}

  </script>-->

  <script type="text/javascript">
    function isChecked(checked, sub1){
    document.getElementById(sub1).disabled = !checkbox.checked;
    }
</script>

  <style type="text/css">
  body{
   /* background-image: url('assets/img/dust_scratches.png');*/
   background-color: #F7F7F7;
    font-family: "Times New Roman", Times, serif;
  }

    #loader{
        position: fixed;
        left: 0px;
        top: 0px;
        width: 100%;
        height: 100%;
        z-index: 9999;
        background: url('<?php echo base_url();?>assets/img/Loading_icon.gif') 50% 50% no-repeat rgb(249,249,249);
        opacity: 1;
    }
    .display-6{
      color: #006bb3;
    }
      #content{
        -webkit-touch-callout: none;
        -webkit-user-select: none;
        -khtml-user-select: none;
        -moz-user-select: none;
        -ms-user-select: none;
        user-select: none;
      }
      #error{
        color: red;
      }

        body{
      background-image: url('<?php echo base_url();?>assets/img/honey_im_subtle.png');

    }

  </style>
</head>
<body>
  <div id="loader"></div>

  <nav class="navbar navbar-expand-lg navbar-light bg-light sticky-top" style="border-bottom: 1px solid #e0e2e4;width: 100%!important" >
  <a class="navbar-brand" href="#"></a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo02" aria-controls="navbarTogglerDemo02" aria-expanded="false" aria-label="Toggle navigation">
  <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarTogglerDemo02">
    <ul class="navbar-nav mr-auto mt-2 mt-lg-0">
    <li class="nav-item">
    <a class="nav-link" href="#"><img src="<?php echo base_url();?>assets/img/mainheader.jpg" width="60%" class="img-responsive"></a>
  </li>
    </ul>
   <!-- <form class="form-inline my-2 my-lg-0">-->
      <button class="btn btn-outline-info my-2 my-sm-0" type="submit" style="border:none"><b>LOGIN</b> </button>&nbsp;&nbsp;<button class="btn btn-outline-info my-2 my-sm-0" type="submit" style="border:none"><b>APPLY ONLINE</b></button>  
    <!--</form>-->
  </div>
</nav>
<br>
<br>
<br>
<!--  <div class="container">
 <div class="row align-items-center" style="background-color: #f0f5f5">
    <div class="col" style="background-color: #00cca3">
       <label style="color: white;padding-top: 20px">STEP.1</label><br>
      <p style="color: white">Applicant Registration</p>

    </div>
    <div class="col" style="background-color:">
       <label style="color:;padding-top: 20px">STEP.2</label><br>
      <p style="color: ">Payment Verification</p>
    </div>
    <div class="col" style="background-color:">
       <label style="padding-top: 20px">STEP.3</label><br>
      <p style="color: ">Exam Schedule</p>
    </div>
     <div class="col" style="background-color:">
       <label style="color: ;padding-top: 20px">STEP.4</label><br>
      <p style="color: ">Take Exam</p>
    </div>
    <div class="col" style="background-color:">
       <label style="color: ;padding-top: 20px">STEP.5</label><br>
      <p style="color: ">Result</p>
    </div>
  </div>
</div> -->

  <div class="container">

    <div class="signup-form-container" style="border-top: none;">
     
         <!-- form start -->
        
     
        <!-- <div class="form-header">          
         </div>-->
                  
         <div class="form-body" style="border-top: 4px solid #00cc7a;border-radius: 4px">
                <div class="container">
                  <?php echo form_close(); ?>
                <?php echo $this->session->flashdata('msg'); ?>
                </div>
              <div class="row">
               <?php if (validation_errors()) : ?>
                  <div class="col-md-12">
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                      <?= validation_errors() ?>
                       <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
                    </div>
                  </div>
                <?php endif; ?>
                <?php if (isset($error)) : ?>
                  <div class="col-md-12">
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                      <?= $error ?>
                      <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
                    </div>
                  </div>
                <?php endif; ?>
            </div>
           <!-- <form onSubmit="return CheckAndSubmit(id)">-->
         <?php echo form_open('Main/user_register');?>
            <!--<form id="register-form"  action="<?php //echo base_url();?>Main/user_register" method="POST">-->
            <div class="alert alert-info" id="message" style="display:none;">
      
              </div>
               <div class="row">             
                   <div class="form-group col-lg-6">
                    <label for="fname">Firstname<font color="#ff4d4d">*</font></label>
                    <div class="input-group">
                   <input name="firstname" type="text"   style=" text-transform:capitalize;" id="firstname" value="<?php echo html_escape(set_value('firstname')); ?>"  class="form-control">
                   </div>
                   <span class="help-block" id="error"></span>                  
                   </div>                           
                   <div class="form-group col-lg-6">
                    <label for="lname">Lastname<font color="#ff4d4d">*</font></label>
                       <div class="input-group">
                   <input name="lastname" type="text" style="  text-transform:capitalize;"  id="lastname" value="<?php echo html_escape(set_value('lastname')); ?>" class="form-control">
                   </div>
                   <span class="help-block" id="error"></span>                
                   </div>           
                 </div>
                 <label for="email">Email Address<font color="#ff4d4d">*</font></label>
                  <div class="form-group">
                   <div class="input-group">
                   <input name="email" type="text" id="email" value="<?php echo html_escape(set_value('email')); ?>" class="form-control">
                   </div> 
                   <span class="help-block" id="error"></span>                     
              </div>
                 
              <div class="row">             
                   <div class="form-group col-lg-6">
                    <label for="password">Password<font color="#ff4d4d">*</font></label>   
                        <div class="input-group">
                        
                        <input name="password" id="password" type="password" value="<?php echo html_escape(set_value('password')); ?>" class="form-control">
                        </div>  
                        <span class="help-block" id="error"></span>                    
                   </div>                           
                   <div class="form-group col-lg-6">
                    <label for="cpassword">Confirm Password<font color="#ff4d4d">*</font></label> 
                        <div class="input-group">
                       
                        <input name="cpassword" type="password" id="password2"  value="<?php echo html_escape(set_value('cpassword')); ?>" class="form-control">
                        </div>  
                        <span class="help-block" id="error"></span>                    
                   </div>           
                 </div>
                    <label for="name">Address<font color="#ff4d4d">*</font></label>
                   <div class="form-group">
                   <div class="input-group">
                   <textarea name="address" type="text" style=" text-transform:capitalize;" id="address" value="<?php echo html_escape(set_value('address')); ?>" class="form-control"></textarea>
                   </div>

                   <span class="help-block" id="error"></span>
              </div> 
                   <label for="name">Contact Number<font color="#ff4d4d">*</font></label>
                   <div class="form-group">
                   <div class="input-group">
                   <input name="contactno" type="text" id="contactno"  value="<?php echo html_escape(set_value('contactno')); ?>" class="form-control" maxlength="11">
                   </div>
                   <span class="help-block" id="error"></span>
              </div> 

               <!--         <div class="input-group">
                          <input name="startdate" type="hidden" class="form-control" >
                        </div>  -->             
   
                   <input type="submit" class="btn btn-info pull-block" name="insert" value="Register">            
              </div>
             </form> 
           </div>
         </div>


<!--end-->
</body>
  </div>
  </div>
</div>
</div>
<script src="<?php echo base_url();?>jquery.min.js"></script>
<script type="text/javascript">
  $(window).on('load', function(){
    //you remove this timeout
    setTimeout(function(){
          $('#loader').fadeOut('slow');  
      }, 1000);
      //remove the timeout
      //$('#loader').fadeOut('slow'); 
  });
</script>
</body>
<center>
<br>
<div class="container">
<div class="footer">
 <p style="text-indent: 0px;word-wrap:break-word;" class="text-muted" id="content"> &copy; <?php echo date('Y');?><!--<?php// echo date("Y");?>--> <font color="#006bb3">ICCT Colleges</font> All Rights Reserved</p>
</div>
</div>
</center>
</html>
    <script src="<?php echo base_url();?>assets2/bootstrap/js/bootstrap.min.js"></script>
    <script src="<?php echo base_url();?>assets2/assets/jquery-1.11.2.min.js"></script>
    <script src="<?php echo base_url();?>assets2/assets/jquery.validate.min.js"></script>
    <script src="<?php echo base_url();?>assets2/assets/register_user.js"></script>
  