<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Auth_model extends CI_Model {


  public function __construct() {
    
    parent::__construct();
    $this->load->database();
    $this->load->helper('date');
    
  }
  

  public function create_register($firstname, $lastname, $email, $password, $cpassword, $address, $contactno) {
    
//$string="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";  
$string="0123456789";
  $code="";
  $limit=10;
  $i=0;
  while($i<=$limit)
  {
    $rand=rand(0,9);
    $code.=$string[$rand]; /*ito po yung ginawa kong pang 'reference number' naka rand(random) lang, di na po ako gumamit ng javascript*/
    $i++;
  }


    $data = array(

      //'Create_at' => date('Y-m-d', now()),
     // 'date' => date('Y-m-d', now())
    
      'firstname'   => $firstname,
      'lastname'  => $lastname,
      'email' => $email,
      'password' => $password,
      'cpassword' => $cpassword,
      'address' => $address,
      'contactno'   => $contactno,
      'code'   => $code,
      'Create_at' => date('Y-M-d', now()),
    );
    $this->db->set('id', FALSE);
    $data = $this->security->xss_clean($data);
    return $this->db->insert('user_client', $data);
    
    }

    /*=======*/

   public function tabs_again($id){
     // $this->db->where('id', $id);
    $up  = $this->db->where('id');
   $up =  $this->db->query("SELECT code,firstname FROM user_client order by id DESC");
      return $up->row();

    }
 /*=======*/

 }