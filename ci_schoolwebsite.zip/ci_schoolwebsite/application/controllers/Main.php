<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Main extends CI_Controller {


	public function __construct() {
		
		parent::__construct();
		$this->load->library(array('session'));
		//$this->load->helper(array('url'));
		$this->load->model('Auth_model');
		$this->load->helper('cookie');
		$this->load->database();
       ///  $this->load->helper('url_helper');
   
	}


	public function index()
	{
		$this->load->view('User/Main_view');
	}

	


	public function view_tabs()
 
	 {

	$this->load->view('User/tabs');

	 }

     public function view_tabs_two()

	 {

	$this->load->view('User/Tabs_two_proceed');

	 }
	
/*========registration ko=========*/

	
	public function user_register() {
		
		// create the data object
		$data = new stdClass();
		
		// load form helper and validation library
		
		$this->load->helper('security');
		///$this->load->helper('date');
		$this->load->library('form_validation');
		
		// set validation rules

	    /* 
         regex_match[/^[a-zA-Z ]+$/] for alpha only
         regex_match[/^[a-zA-Z0-9 ]+$/] for alpha numeric only
         regex_match[/^[0-9]{10,}$/] numeric only
	  	}*/
	  	
       $this->form_validation->set_rules('firstname', 'Firstname', 'trim|required|min_length[3]|firstname_validation');
		function firstname_validation($str){
		Return(! preg_match('/^[a-zA-Z ]*$/', $str)) ? FALSE :TRUE;     	
		}
		$this->form_validation->set_message('firstname_validation', '
		<p class="text-danger">Please enter alphabet characters only</p>
		');
		$this->form_validation->set_rules('lastname', 'lastname', 'trim|required|min_length[3]|lastname_validation');
		function lastname_validation($str){
		Return(! preg_match('/^[a-zA-Z ]*$/', $str)) ? FALSE :TRUE;     	
		}
		$this->form_validation->set_message('lastname_validation', '
		<p class="text-danger">Please enter alphabet characters only</p>
		');
		$this->form_validation->set_rules('email', 'Email', 'trim|required|email_validation');
		function email_validation($str){
		Return(! preg_match('/^(("[\w-\s]+")|([\w-]+(?:\.[\w-]+)*)|("[\w-\s]+")([\w-]+(?:\.[\w-]+)*))(@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$)|(@\[?((25[0-5]\.|2[0-4][0-9]\.|1[0-9]{2}\.|[0-9]{1,2}\.))((25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\.){2}(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\]?$)/i', $str)) ? FALSE :TRUE;     	
		}
		$this->form_validation->set_message('email_validation', '
		<p class="text-danger">Please enter valid Email-ID</p>
		');
		$this->form_validation->set_rules('password', 'Password', 'trim|required|min_length[8]|password_validation');
		function password_validation($str){
		Return(! preg_match('/^.*(?=.{8,})(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%&]).*$/', $str)) ? FALSE :TRUE;     	
		}
		$this->form_validation->set_message('password_validation', '
		<p class="text-danger">Please enter secure and strong password.</p>
		');
		$this->form_validation->set_rules('cpassword', 'Password Confirmation', 'trim|required|matches[password]|cpassword_validation');
		function cpassword_validation($str){
		Return(! preg_match('/^.*(?=.{8,})(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%&]).*$/', $str)) ? FALSE :TRUE;     	
		}
		$this->form_validation->set_message('cpassword_validation', '
		<p class="text-danger">Please Confirm secure and strong password.</p>
		');
		$this->form_validation->set_rules('address', 'Address', 'trim|required|min_length[5]|max_length[100]|address_validation');
		function address_validation($str){
		Return(! preg_match('/^[a-zA-Z0-9 !@#$%^&].*$/', $str)) ? FALSE :TRUE;     	
		}
		$this->form_validation->set_message('address_validation', '
		<p class="text-danger">Please enter valid Address</p>
		');
		$this->form_validation->set_rules('contactno', 'Contact Number', 'trim|required|min_length[10]|max_length[11]|contactno_validation');
		function contactno_validation($str){
		Return(! preg_match('/^[0-9]{10,}$/', $str)) ? FALSE :TRUE;     	
		}
		$this->form_validation->set_message('contactno_validation', '
		<p class="text-danger">Please enter valid mobile no. atleast 10/11 digits</p>
		');

	
		if ($this->form_validation->run() === false) {
			
		
			$this->load->view('User/Tabs', $data);
		
		
			
		} else {
			
			
		    $firstname = $this->security->sanitize_filename($this->input->post('firstname', TRUE));
			$lastname    = $this->security->sanitize_filename($this->input->post('lastname', TRUE));
			$email = $this->security->sanitize_filename($this->input->post('email', TRUE));
			//$password = password_hash( $password, PASSWORD_BCRYPT, array('cost' => 12));
			//hack//-->md5/sha1 at iba pa by:toledo..
			$password  = $this->security->sanitize_filename($this->input->post('password', TRUE));
			$password = password_hash( $password, PASSWORD_BCRYPT); /*Very secure password */
			$cpassword = $this->security->sanitize_filename($this->input->post('cpassword', TRUE));
			$cpassword = password_hash( $cpassword, PASSWORD_BCRYPT); /*Very secure password */
			$address = $this->security->sanitize_filename($this->input->post('address', TRUE));
			$contactno = $this->security->sanitize_filename($this->input->post('contactno', TRUE));
			
			


				$this->load->model('Auth_model'); 
			if($this->Auth_model->create_register($firstname, $lastname, $email, $password, $cpassword, $address, $contactno)) {
				$info = array('firstname' => $firstname,
					         'lastname' => $lastname,
					         'email' => $email,
							 'password' => $password,
							 'cpassword' => $cpassword,
							 'address' => $address,
							 'contactno' => $contactno,
							
							);
			
					
						redirect('Main/successfuly_register');
			} else {
				
				// user creation failed, this should never happen
				$data->error = 'There was a problem creating your new account. Please try again.';			
				
			}
			
		}
	}
public function successfuly_register(){
		$this->session->set_flashdata('msg','<div class="alert alert-success alert-dismissible fade show" role="alert"><h3>Registration Is Successfully!!</h3> <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
</div>');
		redirect('Main/tabs_again');
	
	}

 	public function tabs_again()
	{
            $this->load->model('Auth_model');
           $id = NULL;
			$data['data'] = $this->Auth_model->tabs_again($id);
		     $this->load->view('User/tabs_once_again', $data);
	}



  }



