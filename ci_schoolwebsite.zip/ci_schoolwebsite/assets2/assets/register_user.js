// JavaScript Validation For Registration Page

$('document').ready(function()
{ 		 		
		 // name validation
		  var nameregex = /^[a-zA-Z ]+$/;
		 
		 $.validator.addMethod("validname", function( value, element ) {
		     return this.optional( element ) || nameregex.test( value );
		 }); 
		 
		 // valid email pattern
		 var eregex = /^([a-zA-Z0-9_\.\-\+])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
		 
		 $.validator.addMethod("validemail", function( value, element ) {
		     return this.optional( element ) || eregex.test( value );
		 });
		 
		 $("#register-form").validate({
					
		  rules:

		  {

		  	firstname: {
					required: true,
					validname: true,
					minlength: 2
				},
				lastname: {
					required: true,
					validname: true,
					minlength: 2
				},

				name: {
					required: true,
					validname: true,
					minlength: 4
				},
				email: {
					required: true,
					validemail: true
				},
				password: {
					required: true,
					minlength: 8,
					maxlength: 15
				},
				cpassword: {
					required: true,
					equalTo: '#password'
				},

				address: {
					required: true,
					validname: true,
					minlength: 5
				},

                	contactno: {
					required: true,
					minlength: 10,
					maxlength: 11
				},

		   },
		   messages:
		   {

                 firstname: {
					required: "<font color='#ff4d4d'>Please Enter Firstname</font>",
					validname: "<font color='#990000'>Firstname must contain only alphabets and space</font>",
					minlength: "<font color='#990000'>Your Firstname is Too Short</font>"
					  },

					  lastname: {
					required: "<font color='#ff4d4d'>Please Enter Lastname</font>",
					validname: "<font color='#990000'>Lastname must contain only alphabets and space</font>",
					minlength: "<font color='#990000'>Your Lastname is Too Short</font>"
					  },

                   email: {
					  required: "<font color='#ff4d4d'>Please Enter Email Address</font>",
					  validemail: "<font color='#990000'>Enter Valid Email Address</font>"
					   },

				name: {
					required: "<font color='#ff4d4d'>Please Enter Username</font>",
					validname: "<font color='#990000'>Username must contain only alphabets and space</font>",
					minlength: "<font color='#990000'>Your Username is Too Short</font>"
					  },

			
				password:{
					required: "<font color='#ff4d4d'>Please Enter Password</font>",
					minlength: "<font color='#990000'>Password at least have 8 characters long</font>"
					},
				cpassword:{
					required: "<font color='#ff4d4d'>Please Retype your Password</font>",
					equalTo: "<font color='#990000'>Password Did not Match!</font>"
					},

					address:{
					required: "<font color='#ff4d4d'>Please Enter Address</font>",
					minlength: "<font color='#990000'>Address at least have 5 characters long</font>"
					},
					
					contactno:{
					required: "<font color='#ff4d4d'>Please Enter a Contact Number</font>",
					minlength: "<font color='#990000'>Contact Number at least have 10/11 digits long</font>"

					},
					

		   },
		   errorPlacement : function(error, element) {
			  $(element).closest('.form-group').find('.help-block').html(error.html());
		   },
		   highlight : function(element) {
			  $(element).closest('.form-group').removeClass('has-success').addClass('has-error');
		   },
		   unhighlight: function(element, errorClass, validClass) {
			  $(element).closest('.form-group').removeClass('has-error').addClass('has-success');
			  $(element).closest('.form-group').find('.help-block').html('');
		   },
		   
		   		/*submitHandler: function(form){


					var url = $('#register-form').attr('action');
					location.href=url;

					
				}*/
				
				/*submitHandler: function() 
							   { 
							   		alert("Submitted!");
									$("#register-form").resetForm(); 
							   }*/
		   
		   }); 
		   
		   
	
});